% 
% Copyright (c) 2013 by University of Washington.  All rights reserved. Confidential
%

% validate any changed sg_directives.txt in the current directory
system('/usr/local/basestation/sg_validate.sh')
