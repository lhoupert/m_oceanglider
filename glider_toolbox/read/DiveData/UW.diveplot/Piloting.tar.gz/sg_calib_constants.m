% sg_calib_constants.m			
% values for basestation calculations, diveplot.m, etc.
% last edited 7-Oct-09 F.Stahr

% basic glider and mission params				
id_str = '569';

mass   = 52.337; % for Campos Basin, CT sail
volmax = 51508; % 

mission_title = 'AZUL_03';

rho0 = 1027.5; % for open ocean waters 

% therm_expan = 70.5e-6;    % SG thermal expansion coeff [/degree C]
% temp_ref = 15;  % reference temperature for SG thermal expansion calculation
% abs_compress = 4.18e-6;  % SG vehicle compressibility
% pitchbias = 0; % pitch reference in regressions

% software motor limits
pitch_min_cnts  = 100;
pitch_max_cnts  = 3844;
roll_min_cnts   = 177;
roll_max_cnts   = 3804;
vbd_min_cnts    = 428;
vbd_max_cnts    = 3959;
vbd_cnts_per_cc = -4.0767;

% CT sensors cal constants
calibcomm ='SBE s/n 0203, calibration 01 Apr 2012';% SN and cal date
t_g =  4.33746796E-03; 
t_h =  6.25589267E-04;
t_i =  2.31998200E-05; 
t_j =  2.47537984E-06;

c_g = -9.79891368E+00;
c_h =  1.14976823E+00;
c_i = -2.04117852E-03;
c_j =  2.38369704E-04;

cpcor = -9.5700000E-08;
ctcor = 3.2500000E-06;

% Minimum and maximum frequencies (kHz) for reasonable
%  oceanographic values of conductivity SBE calibration
%  for C/T s/n 041
sbe_cond_freq_min = 2.92434; %kHz
sbe_cond_freq_max = 7.83990; %kHz

% Minimum and maximum frequencies (kHz) for reasonable
%  oceanographic values of temperature from SBE calibration
%  for C/T s/n 0200
sbe_temp_freq_min = 3.143681; %kHz
sbe_temp_freq_max = 6.054158; %kHz

% Oxygen cal constants
comm_oxy_type = 'Aanderaa Optode';
% comm_oxy_type = 'SBE 43F' ;
% calibcomm_oxygen ='SN 0167, 31-Mar-09'; % SN and cal date

%SBE 43F cal constants
% Soc =2.3172E-04;
% Foffset =-865.26;
% % new type of parameters from SBE oxygen
% o_a = --8.2676E-04;
% o_b =  1.1849E-04;
% o_c = -2.7861E-06;
% o_e = 3.60E-02;
% Tau20 = 1.07;
% PCor = 0;   % used as flag to force usage of new algorithm

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Single WET Labs

% Chlorophyll Sensor Coefficients
WETLabsCalData(747).Chl(1).darkCounts  = 47;
WETLabsCalData(747).Chl(1).scaleFactor = 0.0125;

% CDOM Sensor Coefficients
WETLabsCalData(747).CDOM(1).maxOutput   = 4130; % counts
WETLabsCalData(747).CDOM(1).scaleFactor = 0.0946; % ppb/count
WETLabsCalData(747).CDOM(1).darkCounts  = 45; % counts

% Scattering Sensor 650 (wavelength) Coefficients
WETLabsCalData(747).Scatter(1).wavelength  = 650; % nm
WETLabsCalData(747).Scatter(1).scaleFactor = 4.276e-06; % �(?c)/counts 
WETLabsCalData(747).Scatter(1).darkCounts  = 49; % counts 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initial hydrodynamic model params
hd_a = 0.003836;
hd_b = 0.010078; 
hd_c = 9.85E-06; 

% end of file
