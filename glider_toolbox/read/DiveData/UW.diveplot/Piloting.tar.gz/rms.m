function x = rms(y)
   x = sqrt(mean(y.^2));
