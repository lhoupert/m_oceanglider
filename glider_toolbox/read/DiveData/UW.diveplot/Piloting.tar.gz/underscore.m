% 
% Copyright (c) 2012 University of Washington.  All rights reserved. Confidential
% 
%

function [fixed] = undercore(s)
  fixed = strrep(s,'_','\_');