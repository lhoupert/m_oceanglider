% 
% Copyright (c) 2006-2012 by University of Washington.  All rights reserved. Confidential
%

% find any profile file (log, eng, nc or mat), rather than original just log/eng files (see available_runs())
% succinct_elts(available_profiles())
function [runs] = available_profiles()
  sg_calib_constants;
  data_ext = {'nc','log','eng','mat'};
  files = dir(sprintf('p%s*.*',id_str));
  runs = [];
  for file = files'
    file_name = file.name;
    if (file.bytes > 0)
      fields = textscan(file_name,'p%3d%4d.%s');
      for i = 1:size(data_ext,2)
        if (strcmp(fields{3},data_ext{i}))
          runs = [runs ; fields{2}];
          break;
        end
      end
    end
  end
  runs = sort(unique(runs));
